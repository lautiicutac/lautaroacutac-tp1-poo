package ar.org.curso8.poo.tn.tp1.Lautaro_Alonso_Cutac_TN_TP1_RelEntreClases;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LautaroAlonsoCutacTnTp1RelEntreClasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
