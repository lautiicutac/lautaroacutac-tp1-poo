package ar.org.curso8.poo.tn.tp1.lautaro_alonso_cutac_tn_tp1_relentreclases;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LautaroAlonsoCutacTnTp1RelEntreClasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
