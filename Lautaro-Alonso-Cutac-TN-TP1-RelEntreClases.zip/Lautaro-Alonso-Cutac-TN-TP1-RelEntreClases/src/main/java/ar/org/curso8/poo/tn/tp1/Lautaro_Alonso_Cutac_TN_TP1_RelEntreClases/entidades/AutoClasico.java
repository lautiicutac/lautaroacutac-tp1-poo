package ar.org.curso8.poo.tn.tp1.Lautaro_Alonso_Cutac_TN_TP1_RelEntreClases.entidades;

import lombok.Getter;
import lombok.ToString;
@Getter
@ToString(callSuper = true)

public class AutoClasico extends Vehiculo{
    /**
     * constructor con atributos obligatorios:
     * @param color
     * @param marca
     * @param modelo
     */
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }  
    /**
     * constructor con atributos obligatorios más precio.
     * @param color
     * @param marca
     * @param modelo
     * @param precio
     */
    public AutoClasico(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public void informarTipoDeVehiculo() {
        System.out.println("Información sobre este vehículo: Auto Clásico");
    }
}
