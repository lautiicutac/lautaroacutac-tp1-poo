package ar.org.curso8.poo.tn.tp1.lautaro_alonso_cutac_tn_tp1_relentreclases.entidades;
    //  ALT + Z (acoplar las líneas muy largas al ancho de la pantalla)
import lombok.Getter;
import lombok.ToString;
@Getter
@ToString(callSuper = true)

public class AutoNuevo extends Vehiculo{
    /**
     * constructor con los atributos de AutoNuevo obligatorios:
     * @param color
     * @param marca
     * @param modelo
     * @param radio
     */
    public AutoNuevo(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo);
        super.agregarRadio(radio);       // le agrega la Radio que se pase por parámetro a la hora de crear el objeto de AutoNuevo
        if (super.radio ==null) {   // verifica si el autoNuevo sigue sin Radio después de utilizar el método .agregarRadio(radio).
            throw new IllegalAccessError("Error. No se puede crear un AutoNuevo sin Radio (la radio que quiere agregar está en otro Vehículo.)");
        }
    }

    /**
     * constructor con atributos obligatorios más precio.
     * @param color
     * @param marca
     * @param modelo
     * @param precio
     * @param radio
     */
    public AutoNuevo(String color, String marca, String modelo, double precio, Radio radio) {
        super(color, marca, modelo, precio);
        super.agregarRadio(radio);      // le agrega la Radio que se pase por parámetro a la hora de crear el objeto de AutoNuevo
        if (super.radio==null) {    // verifica si el autoNuevo sigue sin Radio después de utilizar el método .agregarRadio(radio).
            throw new IllegalAccessError("Error. No se puede crear un AutoNuevo sin Radio (la radio que quiere agregar está en otro Vehículo.)");                
        }
    }

    @Override
    public void informarTipoDeVehiculo() {
        System.out.println("Información sobre este vehículo: Auto Nuevo");
    }

    //a continuación los métodos agregarRadio y cambiarRadio de la clase padre se sobreescriben "vacíos" para que los mismos no hagan ningun cambio sobre esta clase AutoNuevo.
    
    /**
     * metodo agregarRadio "vacío" indicando que no es posible utilizar éste método
     */
    @Override
    public void agregarRadio(Radio nuevaRadio){
        System.out.println("Buen intento, pero no se le puede 'agregar' una radio a un AutoNuevo, ya que el mismo no puede estar sin una. Utilice el método '.cambiarRadio(radio)' para intercambiarla por otra.");
    }

    /**
     * método retirarRadio "vacío"
     */
    @Override
    public void retirarRadio(){
        System.out.println("Lo siento, pero no se puede dejar un AutoNuevo sin una Radio. Utilice el método '.cambiarRadio(radio)' para intercambiarla por otra.");
    }

    /**
     * método para intercambiar la radio que tenga un AutoNuevo por otra.
     * @param radio : por parámetro se ingresa la radio a la que se desea cambiar.
     */
    public void cambiarRadio(Radio nuevaRadio){
        if (nuevaRadio != null) {       //si la nueva radio tiene valores/no es null
            if (this.radio != null) {   //si en este autoNuevo hay una radio
                System.out.print("Se ha cambiado la radio del vehículo " + this);
                radio.desocuparRadio(); //cambia el estado de enUso a false
                this.radio=null;        //retira la radio actual del autoNuevo
            }
            this.radio = nuevaRadio;    //asigna la nuevaRadio al autoNuevo
            this.radio.ocuparRadio();   //cambia el estado de enUso a true
            System.out.println(" por la siguiente " + nuevaRadio + "." );
        }else{
            System.out.println("FATAL ERROR: Imposible cambiar la Radio. La radio que quiere ingresar no puede ser 'null'.");
        }
    }
}
