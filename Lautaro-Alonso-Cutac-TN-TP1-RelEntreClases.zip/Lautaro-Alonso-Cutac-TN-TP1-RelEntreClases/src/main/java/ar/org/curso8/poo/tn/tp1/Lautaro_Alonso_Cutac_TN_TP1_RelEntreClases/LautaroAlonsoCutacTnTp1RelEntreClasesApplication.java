package ar.org.curso8.poo.tn.tp1.Lautaro_Alonso_Cutac_TN_TP1_RelEntreClases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LautaroAlonsoCutacTnTp1RelEntreClasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LautaroAlonsoCutacTnTp1RelEntreClasesApplication.class, args);
	}

}
