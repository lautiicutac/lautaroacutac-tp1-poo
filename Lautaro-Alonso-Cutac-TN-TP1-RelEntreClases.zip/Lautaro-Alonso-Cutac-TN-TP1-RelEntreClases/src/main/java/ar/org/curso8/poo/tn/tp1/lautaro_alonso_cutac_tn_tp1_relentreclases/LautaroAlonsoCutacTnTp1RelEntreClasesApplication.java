package ar.org.curso8.poo.tn.tp1.lautaro_alonso_cutac_tn_tp1_relentreclases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LautaroAlonsoCutacTnTp1RelEntreClasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LautaroAlonsoCutacTnTp1RelEntreClasesApplication.class, args);
	}

}
