package ar.org.curso8.poo.tn.tp1.lautaro_alonso_cutac_tn_tp1_relentreclases.entidades;
    //   ALT + Z (acoplar las líneas muy largas al ancho de la pantalla)
import lombok.Getter;
import lombok.ToString;
@Getter
@ToString

public abstract class Vehiculo {    //clase abstracta: no se pueden crear objetos de la clase Vehiculo.
    private String color;
    private String marca;
    private String modelo;
    private double precio;
    // @Setter(AccessLevel.NONE)
    protected Radio radio;

    /**
     * constructor con los atributos obligatorios (color, marca y modelo).
     * @param color
     * @param marca
     * @param modelo
     */
    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * constructor con los atributos obligatorios más precio.
     * @param color
     * @param marca
     * @param modelo
     * @param precio
     */
    public Vehiculo(String color, String marca, String modelo, double precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    //setters de lo que considero que es obligatorio/más necesario
    /**
     * cambiar o agregarle un precio (si el vehiculo se creó sin un precio o en 0$).
     * @param color
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    /**
     * si se desea cambiar el color una vez creado
     * @param color
     */
    public void setColor(String color) {
        this.color = color;
    }
    //setters por si hubo algún error humano de tipeo a la hora de crear el objeto, y el mismo ya está creado con el nombre mal escrito.
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * método abstracto que se sobreescribe en las subclases.  
     */
    public abstract void informarTipoDeVehiculo();
    
    /**
     * método para agregar una Radio nueva al vehículo, si ésta radio que queremos implementar no está en otro vehículo, y si el vehículo no tiene una.
     * @param nuevaRadio recibe el objeto de Radio que se desee agregar.
     */
    public void agregarRadio(Radio nuevaRadio) { 
        if (nuevaRadio.isEnUso()) {      //primero se verifica si la nuevaRadio está en otro vehículo
            System.out.println("¡La radio que quiere añadir (" + nuevaRadio + ") está en otro vehículo! No se puede cometer tal acción. Retirela de dicho vehículo utilizando '.retirarRadio()'");
        }else { 
            if (this.radio!=null) {     //verifica si este vehículo tiene una radio
                System.out.println("Ya hay una radio en el vehículo "+ this + ", retírela del mismo utilizando el método '.retirarRadio(radio)' e intente esta acción '.agregarRadio(radio)' nuevamente");
            }else{
                nuevaRadio.ocuparRadio();   //cambia el estado del atributo enUso a true
                this.radio=nuevaRadio;
                System.out.println("La radio " + nuevaRadio + " ha sido agregada al vehículo "+ this +". Disfrute del viaje con música en alta fidelidad y volúmen sin saturación. (ADVERTENCIA: Al poner reggaeton la radio explotará automáticamente).");
            }
        }
    }
    /**
     * método para retirar la radio del vehiculo.
     * @param radio
     */
    public void retirarRadio(){
        if (this.radio==null){ //verifica si el vehículo no tiene Radio: no hay radio que retirar.
            System.out.println("Imposible retirar: radio no encontrada en este vehiculo.");
        }else { 
            System.out.println("Retirando "+radio+"del vehiculo "+this+"...");
            radio.desocuparRadio();     //cambia el estado del atributo enUso a false
            this.radio=null;
            System.out.println("Extracción realizada: Vehículo actual sin radio. Radio disponible para instalar en otro vehículo.");
        }  
    }

    
    
}
