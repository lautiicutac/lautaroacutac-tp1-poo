package ar.org.curso8.poo.tn.tp1.Lautaro_Alonso_Cutac_TN_TP1_RelEntreClases.entidades;

import lombok.Getter;
import lombok.ToString;
@Getter
@ToString(callSuper = true)

public class AutoNuevo extends Vehiculo{
    /**
     * constructor con los atributos de AutoNuevo obligatorios:
     * @param color
     * @param marca
     * @param modelo
     * @param radio
     */
    public AutoNuevo(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo);
    }
    /**
     * constructor con atributos obligatorios más precio.
     * @param color
     * @param marca
     * @param modelo
     * @param precio
     * @param radio
     */
    public AutoNuevo(String color, String marca, String modelo, double precio, Radio radio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public void informarTipoDeVehiculo() {
        System.out.println("Información sobre este vehículo: Auto Nuevo");
    }
}
